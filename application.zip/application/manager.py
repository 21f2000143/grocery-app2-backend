from flask import current_app as app
from flask import redirect, url_for, render_template, request, flash
from flask_security import Security, current_user, auth_required, hash_password, \
     SQLAlchemySessionUserDatastore, permissions_accepted, roles_required
from application.database import db_session
from application.models import *
from functools import wraps

# Helpful functions
def add_role(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        if current_user:
            roles=app.security.datastore.find_or_create_role(
                name="user", permissions=["user-read", "user-write"]
            )
            db_session.commit()
            app.security.datastore.add_role_to_user(current_user,roles)
            db_session.commit()
        return func(*args, **kwargs)

    return wrapper

# Views: Manager
@app.route("/admin")
@auth_required()
@add_role
@roles_required('admin')
def admin_home():
    return render_template('manager.html')

@app.route("/add_category", methods=['GET', 'POST'])
@auth_required()  # Replace with your authentication decorator
def add_category():
    if request.method == 'POST':
        name = request.form['name']
        new_category = Category(name=name)

        try:
            db_session.add(new_category)
            db_session.commit()
            flash('Category added successfully!', 'success')
        except:
            db_session.rollback()
            flash('Category with the same name already exists!', 'danger')

    return render_template('add_category.html')

@app.route("/add_product", methods=['GET', 'POST'])
@auth_required()  # Replace with your authentication decorator
def add_product():
    if request.method == 'POST':
        name = request.form['name']
        manufacture_date = request.form['manufacture_date']
        expiry_date = request.form['expiry_date']
        rate_per_unit = request.form['rate_per_unit']
        unit = request.form['unit']
        category_id = request.form['category_id']

        new_product = Product(
            name=name,
            manufacture_date=manufacture_date,
            expiry_date=expiry_date,
            rate_per_unit=rate_per_unit,
            unit=unit,
            category_id=category_id
        )

        try:
            db_session.add(new_product)
            db_session.commit()
            flash('Product added successfully!', 'success')
        except:
            db_session.rollback()
            flash('An error occurred while adding the product.', 'danger')

    return render_template('add_product.html')

# View for updating a product
@app.route("/update_product/<int:product_id>", methods=['GET', 'POST'])
@auth_required()  # Replace with your authentication decorator
def update_product(product_id):
    product = Product.query.get(product_id)

    if not product:
        flash('Product not found!', 'danger')
        return redirect(url_for('home'))  # Redirect to the home page or another appropriate page

    if request.method == 'POST':
        product.name = request.form['name']
        product.manufacture_date = request.form['manufacture_date']
        product.expiry_date = request.form['expiry_date']
        product.rate_per_unit = request.form['rate_per_unit']
        product.unit = request.form['unit']
        product.category_id = request.form['category_id']

        try:
            db_session.commit()
            flash('Product updated successfully!', 'success')
            return redirect(url_for('home'))  # Redirect to the home page or another appropriate page
        except:
            db_session.rollback()
            flash('An error occurred while updating the product.', 'danger')

    return render_template('update_product.html', product=product)

# View for deleting a product
@app.route("/delete_product/<int:product_id>", methods=['GET', 'POST'])
@auth_required()  # Replace with your authentication decorator
def delete_product(product_id):
    product = Product.query.get(product_id)

    if not product:
        flash('Product not found!', 'danger')
        return redirect(url_for('home'))  # Redirect to the home page or another appropriate page

    if request.method == 'POST':
        try:
            db_session.delete(product)
            db_session.commit()
            flash('Product deleted successfully!', 'success')
            return redirect(url_for('home'))  # Redirect to the home page or another appropriate page
        except:
            db_session.rollback()
            flash('An error occurred while deleting the product.', 'danger')

    return render_template('delete_product.html', product=product)

# View for updating a category
@app.route("/update_category/<int:category_id>", methods=['GET', 'POST'])
@auth_required()  # Replace with your authentication decorator
def update_category(category_id):
    category = Category.query.get(category_id)

    if not category:
        flash('Category not found!', 'danger')
        return redirect(url_for('home'))  # Redirect to the home page or another appropriate page

    if request.method == 'POST':
        category.name = request.form['name']

        try:
            db_session.commit()
            flash('Category updated successfully!', 'success')
            return redirect(url_for('home'))  # Redirect to the home page or another appropriate page
        except:
            db_session.rollback()
            flash('An error occurred while updating the category.', 'danger')

    return render_template('update_category.html', category=category)
# View for deleting a category
@app.route("/delete_category/<int:category_id>", methods=['GET', 'POST'])
@auth_required()  # Replace with your authentication decorator
def delete_category(category_id):
    category = Category.query.get(category_id)

    if not category:
        flash('Category not found!', 'danger')
        return redirect(url_for('home'))  # Redirect to the home page or another appropriate page

    if request.method == 'POST':
        try:
            db_session.delete(category)
            db_session.commit()
            flash('Category deleted successfully!', 'success')
            return redirect(url_for('home'))  # Redirect to the home page or another appropriate page
        except:
            db_session.rollback()
            flash('An error occurred while deleting the category.', 'danger')

    return render_template('delete_category.html', category=category)
